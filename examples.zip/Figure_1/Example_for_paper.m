%This script tests the basic set up to do the full brain exivalence test.
%It simulates some data as experimental and control that can be dependent
%or independent (sett by cor). Sample size and voxels can be set and are
%rows and columns of experimental and control, respectively. Then different
%ways to calculate effect sizes are implemented manually. Since calculating
%CIs around effect sizes is not trivial, I use a toolbox that needs to be
%cloned from github. It calculates Hedge's g, which is just another name
%for Cohen's d and CIs. It behaves exactly as would be expected, when the
%input is manipulated. From here we can start to implement a two
%dimensional visualisation that can guide the visuals for the whole brain
%data. We can also implement spatial correlations and spatially confined
%effects.

rng(50);
get_seed = rng;
 
 
%set some variables
N = 500; %population per group
n = 50; %sample size per group
voxels = [30 30];%voxels (somewhere I have hard coded this, so currently cannot be set)
number_effects = 1;
c_mean = 0; %the mean of the control condition 
c_sd = 1; %the SD of the control condition (IDEA: to test the effects of SNR we can change this across the voxels)
effect = zeros(voxels(1),voxels(2)); 

%here we set some hand-picked voxels to have an effect on the plane
E1 = zeros(voxels(1),voxels(2))==1; 
E2 = zeros(voxels(1),voxels(2))==1; 
E3 = zeros(voxels(1),voxels(2))==1; 
E1(10,20) = 1;
E2(15,20) = 1;
E3(20,20) = 1;
effect(E1) = 0.8; 
effect(E2) = 0.8;   
effect(E3) = 0.45; 


h = fspecial('gaussian',3); %make a gaussian filter
effect = filter2(h,effect); %apply the filter to effect
expected_effects = [effect(10,20) effect(15,20) effect(20,20) ];%expected effects after smooting
effect = permute(repmat(effect,1,1,N),[3 1 2]); %make an effect per subject



%this sets up some small effects, as should realistically be expected
small_effects = permute(repmat(abs(normrnd(0,0.01,voxels(1),voxels(2))),1,1,N),[3 1 2]);
%make sure not to change the expected effects using logical indexing
exclude_effects = ones(500,voxels(1),voxels(2));
exclude_effects(:,[10 15 20],20) = 0;
small_effects = (small_effects.*exclude_effects);

%this adds the small effects %%%%%%%%CURRENTLY OFF !!!!
% effect = effect + small_effects;





%set the correlation of control and experimental condition (for independent groups set c to 0)
cor = 0;
cor_inv = c_sd*sqrt(1-cor^2); %This determines how much of the variance is not yet accounted for by the correlation

%Generate normal distributed control measurements 
control =  normrnd(c_mean,c_sd,N,voxels(1),voxels(2));

%Generate normal distributed experimental measurements 
experimental = control.*cor+normrnd((1-cor)*c_mean,cor_inv,N,voxels(1),voxels(2))+effect;

%check whether the correlation is as intended
CORR = corr(control(:,1),experimental(:,1));

%add a moving average to the data, so that it is spatially correlated
k = 3; %set the extent of smoothing, high frequency noise (and effects) will be attenuated by this!

%set gaussian filte
h = fspecial('gaussian',k); %make a gaussian filter

%apply the filter to temporary data and then overwrite the olf data
for i = 1:N
    control_T(i,:,:) = filter2(h,squeeze(control(i,:,:)));
end
control = control_T;

for i = 1:N
    experimental_T(i,:,:) = filter2(h,squeeze(experimental(i,:,:)));
end
experimental = experimental_T;


%reduce from population to sample
sample = randi(N,n,1);

experimental = experimental(sample,:,:);
control = control(sample,:,:);

%calculate Cohen's d using mean and SD
C_d_1 = (mean(experimental,1)-mean(control,1))./((std(control,1)+std(experimental,1))/2);

%plot Cohen's d
%mesh(squeeze(C_d_1));

%tell MATLAB where to find the effect size toolbox (you need to clone the repository from github and then set the correct path here)
addpath("C:\Github_Repos\measures-of-effect-size-toolbox");

%Reshape the grouping variables, so that MES toolbox doesn't have to do
%that and we retain control
% experimental_V = reshape(experimental,N,numel(experimental)/N);
% control_V = reshape(control,N,numel(control)/N);



%calculate Hedges g (a common version of Cohen's d) using the toolbox (automatically calculates the 95% CI too)
%H_g_1 = mes(experimental,control,'hedgesg'); 

%calculate Hedges g (a common version of Cohen's d) using the toolbox
%(setting 90% CI) <-- this is what we want for independent samples
H_g_2 = mes(experimental,control,'hedgesg','confLevel',0.90);

%calculate Hedges g (a common version of Cohen's d) using the toolbox
%(setting 99.9% CI) <-- this is what we want for whole brain significance
%testing
H_g_3 = mes(experimental,control,'hedgesg','confLevel',0.999);

%get the highest hedges_g

effect_emp = max(H_g_2.hedgesg);



%reshape the output of the MES toolbox back to our original format
uCI_M = reshape(H_g_2.hedgesgCi(2,:),voxels(1),voxels(2));
lCI_M = reshape(H_g_2.hedgesgCi(1,:),voxels(1),voxels(2));
ES_M = reshape(H_g_2.hedgesg,voxels(1),voxels(2));

u999CI_M = reshape(H_g_3.hedgesgCi(2,:),voxels(1),voxels(2));
l999CI_M = reshape(H_g_3.hedgesgCi(1,:),voxels(1),voxels(2));



%make a meshgrid
[X,Y] = meshgrid(0.1:0.1:30);

%scale the data
uCI_M_scaled = interp2(uCI_M,X,Y,'cubic');
lCI_M_scaled = interp2(lCI_M,X,Y,'cubic');
ES_M_scaled = interp2(ES_M,X,Y,'cubic');
u999CI_M_scaled = interp2(u999CI_M,X,Y,'cubic');
l999CI_M_scaled = interp2(l999CI_M,X,Y,'cubic');

%get a brain image as a matrix
brain_mask = imresize(imread('Mask_pic.jpg'),[size(Y,1) size(Y,1)]);
brain_mask = imrotate(brain_mask, 180);
brain_mask = (brain_mask < 200);


uCI_M_scaled(brain_mask) = NaN;
lCI_M_scaled(brain_mask) = NaN;
ES_M_scaled(brain_mask) = NaN;
u999CI_M_scaled(brain_mask) = NaN;
l999CI_M_scaled(brain_mask) = NaN;

%get the highest hedges_g

effect_emp = max(ES_M_scaled(:));

%get the smallest and largest upper CI value
min_ES = min(ES_M_scaled(:));
max_ES = max(ES_M_scaled(:));

%get the maximum upper CI value
[max_CI_indx(1), max_CI_indx(2)] = find(uCI_M_scaled == max(uCI_M_scaled(:)));


%plot the surface plot
surface_p = mesh(ES_M_scaled,'FaceAlpha','0.8');
surface_p.FaceColor = 'interp';
surface_p.EdgeColor = 'none';
colormap(jet)
caxis([min_ES max_ES])

set(gca,'FontSize',16)

%here you can specify the acis labels
xlabel('Voxels')
ylabel('Voxels')
zlabel('Effect size')

%set the z-axis limits
zlim([min_ES 2])

%add a plane to the plot
hold  on
[Y_s,Z_s] = meshgrid(1:0.5:300,-1:0.1:2);
X_s = zeros(size(Y_s,1),size(Y_s,2))+max_CI_indx(2);
plane_p = mesh(X_s,Y_s,Z_s,'FaceAlpha','0.4');
plane_p.FaceColor = [0 0.8 0.8];
plane_p.EdgeColor = 'none';

%add a line to the plot at the highest effect
hold  on
X_l = [max_CI_indx(2) max_CI_indx(2)];
Y_l = [1 300];
Z_l = [effect_emp effect_emp];
line_p = line(X_l,Y_l,Z_l, 'Color','red');

%get a brain image as a matrix
brain_im = imread('Brain_pic.jpg');
brain_im = imrotate(brain_im, 180);
% brain_im(:,:,2) = imread('Brain.jpg');
% brain_im(:,:,3) = imread('Brain.jpg');

% imshow(brain_im)

xImage = [0 300; 0 300];   % The x data for the image corners
yImage = [0 0; 300 300];             % The y data for the image corners
zImage = [min_ES min_ES; min_ES min_ES];   % The z data for the image corners

image_p = surf(xImage,yImage,zImage,...    % Plot the surface
     brain_im ,...
     'FaceColor','texture');
 
 grid off %here xou can toggle the grid
 axis on
 box off

 
hold off
 
figure 

%plot a 2-d version with much more info in it
%set the x axis
X = 1:size(Y,1);
valid = ~isnan(lCI_M_scaled(:,max_CI_indx(2)));
%plot Hedges g 2 and the 90% CI bounds
ES_plot = plot(X,ES_M_scaled(:,max_CI_indx(2)),'k',...
               X,lCI_M_scaled(:,max_CI_indx(2)),'g--',...
               X,uCI_M_scaled(:,max_CI_indx(2)),'b--',...
               X,l999CI_M_scaled(:,max_CI_indx(2)),'g--',...
               X,u999CI_M_scaled(:,max_CI_indx(2)),'b--');
%change line width for the first line
ES_plot(1).LineWidth = 2;
ES_plot(4).LineStyle = 'none';
ES_plot(5).LineStyle = 'none';

set(gca,'FontSize',16)

x0=10;
y0=10;
width=800;
height=400;
set(gcf,'position',[x0,y0,width,height])

%hold all
hold on
% add shaded areas to the plot
X2 = [ X(valid)' ; flipud(X(valid)') ];
inBetween = [ES_M_scaled(valid,max_CI_indx(2)) ; flipud(lCI_M_scaled(valid,max_CI_indx(2)))];
fill_lCI = fill(X2, inBetween, 'g');
set(fill_lCI,'EdgeColor','none')
set(fill_lCI,'FaceAlpha',0.5)
inBetween = [ES_M_scaled(valid,max_CI_indx(2)) ; flipud(uCI_M_scaled(valid,max_CI_indx(2)))];
fill_uCI = fill(X2, inBetween, 'b');
set(fill_uCI,'EdgeColor','none')
set(fill_uCI,'FaceAlpha',0.5)
inBetween = [uCI_M_scaled(valid,max_CI_indx(2)) ; flipud(u999CI_M_scaled(valid,max_CI_indx(2)))];
fill_u999CI = fill(X2, inBetween, 'b');
set(fill_u999CI,'EdgeColor','none')
set(fill_u999CI,'FaceAlpha',0.2)
inBetween = [lCI_M_scaled(valid,max_CI_indx(2)) ; flipud(l999CI_M_scaled(valid,max_CI_indx(2)))];
fill_l999CI = fill(X2, inBetween, 'g');
set(fill_l999CI,'EdgeColor','none')
set(fill_l999CI,'FaceAlpha',0.2)


%plot lines
line_plot = plot( X(valid),repmat(effect_emp,sum(valid),1),'r',...
               X(valid),zeros(sum(valid),1),'k');

%find where the effects were set
[e11, e12] = find(E1);
[e21, e22] = find(E2);
[e31, e32] = find(E3);
           
%plot some text for the effects
III = text(e11*10,-0.5,"III",'Color','k','FontSize',18,...
            'FontWeight', 'bold', 'FontName', 'Times New Roman');
        
set(III,'HorizontalAlignment','center');

II = text(e21*10,-0.5,"II",'Color','k','FontSize',18,...
            'FontWeight', 'bold', 'FontName', 'Times New Roman');
        
set(II,'HorizontalAlignment','center');

I = text(e31*10 ,-0.5,"I",'Color','k','FontSize',18,...
            'FontWeight', 'bold', 'FontName', 'Times New Roman');

set(I,'HorizontalAlignment','center');

%set X axis label
xlabel("Voxels")

%set y axis limits
ylim([-1 2])

xlim([50 250])

%set Y axis label
ylabel("Effect Size")

ES_plot(4).HandleVisibility = 'off';
ES_plot(5).HandleVisibility = 'off';
fill_lCI.HandleVisibility = 'off';
fill_uCI.HandleVisibility = 'off';


%set legend
legend("Hedge's g","Lower bound (90% CI)","Upper bound (90% CI)",...
    "Lower bound (99.9% CI)","Upper bound (99.9% CI)","Maximum Effect","Null hypothesis",...
     'Location', 'eastoutside');

%reverse x-axis
set(gca, 'XDir','reverse')

box off
legend boxoff

hold off
figure

%Plot the brain image 
brain_figure = image(imresize(brain_im,[size(Y,1) size(Y,1)]));
%set the width and heght to get good dimensions
x0=10;
y0=10;
width=420;
height=400;
set(gcf,'position',[x0,y0,width,height])
set(gca,'FontSize',16)
hold on
red_line = plot(ones(300,1)*200,1:300,'r');
I = plot(e12*10,e11*10,'.', 'MarkerSize', 80*expected_effects(1));
II = plot(e22*10,e21*10,'.', 'MarkerSize', 80*expected_effects(2));
III = plot(e32*10,e31*10,'.', 'MarkerSize', 80*expected_effects(3));
text(e12*10 + 10,e11*10,"III",'Color','black','FontSize',18,...
    'FontWeight', 'bold', 'FontName', 'Times New Roman');

text(e22*10 + 10,e21*10,"II",'Color','black','FontSize',18,...
    'FontWeight', 'bold', 'FontName', 'Times New Roman');

text(e32*10 + 10,e31*10,"I",'Color','black','FontSize',18,...
    'FontWeight', 'bold', 'FontName', 'Times New Roman');


%set  axis labels
xlabel("Voxels")
ylabel("Voxels")
yticks([0 100 200 300]);

% %reverse Y-axis
set(gca, 'YDir','normal')



